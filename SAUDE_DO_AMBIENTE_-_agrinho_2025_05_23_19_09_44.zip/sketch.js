 let ambiente;
let plantas = [];
let animais = [];
let poluicao = 0;
let taxaPoluicao = 0.01;
let taxaLimpezaPlanta = 0.005;

function setup() {
  createCanvas(600, 400);
  ambiente = new Ambiente();
}

function draw() {
  background(100, 150, 200); // Cor de fundo do céu

  ambiente.atualizar();
  ambiente.mostrar();

  for (let i = plantas.length - 1; i >= 0; i--) {
    plantas[i].crescer();
    plantas[i].mostrar();
    ambiente.saude += taxaLimpezaPlanta; // Plantas ajudam a limpar
    if (plantas[i].morreu()) {
      plantas.splice(i, 1);
    }
  }

  for (let i = animais.length - 1; i >= 0; i--) {
    animais[i].mover();
    animais[i].mostrar();
    // Adicionar lógica de interação com plantas/outros animais e impacto no ambiente
    if (animais[i].morreu()) {
      animais.splice(i, 1);
    }
  }

  poluicao += taxaPoluicao;
  ambiente.saude -= poluicao * 0.001; // Poluição diminui a saúde

  // Limitar a saúde entre 0 e 1
  ambiente.saude = constrain(ambiente.saude, 0, 1);

  // Exibir informações (opcional)
  fill(255);
  text(`Saúde do Ambiente: ${nf(ambiente.saude, 2)}`, 10, 20);
  text(`Poluição: ${nf(poluicao, 2)}`, 10, 40);
  text(`Plantas: ${plantas.length}`, 10, 60);
  text(`Animais: ${animais.length}`, 10, 80);
}

function mouseClicked() {
  // Adicionar uma nova planta onde o mouse é clicado
  plantas.push(new Planta(mouseX, mouseY));
}

function keyPressed() {
  if (key === 'p' || key === 'P') {
    // Simular poluição ao pressionar 'P'
    poluicao += 0.1;}

  if (key === 'a' || key === 'A') {
    animais.push(new Animal(random(width), random(height)));
  }
}

class Ambiente {
  constructor() {
    this.saude = 1; // Inicialmente saudável
  }

  atualizar() {
    // Adaptações do ambiente baseadas na saúde (opcional)
  }

  mostrar() {
    // Representação visual da terra/água
    fill(34, 139, 34);
    rect(0, height * 0.6, width, height * 0.4);
    // Sobreposição visual para indicar a saúde
    let corSaude = color(0, 255, 0, (1 - this.saude) * 100); // Mais transparente quanto menos saudável
    fill(corSaude);
    rect(0, 0, width, height);
    // Sobreposição visual para indicar a poluição
    let corPoluicao = color(100, 100, 100, poluicao * 10); // Mais opaco com mais poluição
    fill(corPoluicao);
    rect(0, 0, width, height);
  }
}

class Planta {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.tamanho = 25;
    this.taxaCrescimento = 0.01 + random(0.02);
    this.saude = 1;
  }

  crescer() {
    this.tamanho += this.taxaCrescimento;
    this.saude -= poluicao * 0.0005;
    this.saude = constrain(this.saude, 0, 1);
  }

  morreu() {
    return this.saude <= 0;
  }

  mostrar() {
    fill(0, 150, 0);
    ellipse(this.pos.x, this.pos.y - this.tamanho / 2, this.tamanho, this.tamanho);
  }
}

class Animal {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D();
    this.vel.mult(random(0.5, 1));
    this.tamanho = 20;
    this.saude = 1;
  }

  mover() {
    this.pos.add(this.vel);
    this.saude -= poluicao * 0.0001;
    this.saude = constrain(this.saude, 0, 1);
    this.bordas();
  }

  morreu() {
    return this.saude <= 0;
  }

  mostrar() {
    fill(200, 100, 50);
    ellipse(this.pos.x, this.pos.y, this.tamanho, this.tamanho);
  }

  bordas() {
    if (this.pos.x < 0 || this.pos.x > width) {
      this.vel.x *= -1;
    }
    if (this.pos.y < 0 || this.pos.y > height) {
      this.vel.y *= -1;
    }
  }
}